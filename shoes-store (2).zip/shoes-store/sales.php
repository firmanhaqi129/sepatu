<?php
// Sertakan file koneksi ke database
include_once 'dbconection.php';

// Query untuk mengambil data sales beserta detailnya
$sql = "SELECT sales.id AS sale_id, customers.name AS customer_name, sales.sale_date, SUM(sales_details.quantity) AS total_items, SUM(sales_details.quantity * sales_details.price) AS total_amount
        FROM sales
        INNER JOIN customers ON sales.customer_id = customers.id
        INNER JOIN sales_details ON sales.id = sales_details.sale_id
        GROUP BY sales.id";
$stmt = $dbh->query($sql);

// CSS Style untuk tabel
echo '<style>
        /* Aturan CSS untuk menyesuaikan tampilan tabel */
        .container {
            margin-top: 50px;
            width: 80%;
            margin: 0 auto;
        }
        .table {
            font-size: 16px;
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .table th,
        .table td {
            color: #000; /* Warna font hitam */
            border: 1px solid #ddd; /* Garis tepi */
            padding: 8px;
            text-align: left;
        }
        .table th {
            background-color: #f2f2f2; /* Warna latar belakang header */
        }
        .table-striped tbody tr:nth-child(odd) {
            background-color: #f9f9f9; /* Warna latar belakang setiap baris ganjil */
        }
        .table-striped tbody tr:nth-child(even) {
            background-color: #fff; /* Warna latar belakang setiap baris genap */
        }
    </style>';

// Cek apakah ada data sales
if ($stmt->rowCount() > 0) {
    ?>
    <div class="container">
        <h1>Sales</h1>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Sale ID</th>
                        <th>Customer Name</th>
                        <th>Sale Date</th>
                        <th>Total Items</th>
                        <th>Total Amount</th>
                        <!-- Tambahkan kolom lain jika perlu -->
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Loop untuk menampilkan data sales
                    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                        ?>
                        <tr>
                            <td><?php echo $row['sale_id']; ?></td>
                            <td><?php echo $row['customer_name']; ?></td>
                            <td><?php echo $row['sale_date']; ?></td>
                            <td><?php echo $row['total_items']; ?></td>
                            <td><?php echo number_format($row['total_amount'], 2); ?></td>
                            <!-- Tambahkan kolom lain jika perlu -->
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
} else {
    // Tampilkan pesan jika tidak ada data sales
    echo "<div class='container'><p>No sales found.</p></div>";
}
?>

<!-- Button untuk menampilkan ringkasan penjualan dan pembayaran -->
<div class="container" style="margin-top: 50px;">
    <form action="view_summary.php" method="get">
        <button type="submit" class="btn btn-primary">View Sales Summary</button>
    </form>
</div>

<!-- Button untuk menampilkan total_sales_by_category.php -->
<div class="container" style="margin-top: 50px;">
    <form action="total_sales_by_category.php" method="get">
        <!-- <label for="category">Select Category:</label> -->
        <!-- <select name="category" id="category">
            <option value="">Select Category</option>
            <?php
            // Query untuk mengambil data kategori sepatu
            $sql_categories = "SELECT * FROM categories";
            $stmt_categories = $dbh->query($sql_categories);

            // Tampilkan opsi kategori dalam dropdown
            while ($row_category = $stmt_categories->fetch(PDO::FETCH_ASSOC)) {
                echo '<option value="' . $row_category['id'] . '">' . $row_category['name'] . '</option>';
            }
            ?>
        </select> -->
        <button type="submit" class="btn btn-primary">Show Sales by Category</button>
    </form>
</div>


<!-- Tambahkan jeda di antara tabel Sales dan tabel Sales Details -->
<div style="margin-top: 50px;"></div>

<?php
// Query untuk mengambil data sales details
$sql_details = "SELECT sales.id AS sale_id, shoes.name AS shoe_name, sales_details.quantity, sales_details.price, (sales_details.quantity * sales_details.price) AS subtotal
                FROM sales
                INNER JOIN sales_details ON sales.id = sales_details.sale_id
                INNER JOIN shoes ON sales_details.shoe_id = shoes.id";
$stmt_details = $dbh->query($sql_details);
?>

<?php if ($stmt_details->rowCount() > 0): ?>
    <div class="container">
        <h2>Sales Details</h2>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Sale ID</th>
                        <th>Shoe Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row_details = $stmt_details->fetch(PDO::FETCH_ASSOC)): ?>
                        <tr>
                            <td><?php echo $row_details['sale_id']; ?></td>
                            <td><?php echo $row_details['shoe_name']; ?></td>
                            <td><?php echo $row_details['quantity']; ?></td>
                            <td><?php echo number_format($row_details['price'], 2); ?></td>
                            <td><?php echo number_format($row_details['subtotal'], 2); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php else: ?>
    <div class="container">
        <p>No sales details found.</p>
    </div>
<?php endif; ?>

<!-- Button untuk menampilkan detail penjualan sepatu bersama dengan detail sepatu -->
<div class="container" style="margin-top: 50px;">
    <form action="view_sales_details.php" method="get">
        <button type="submit" class="btn btn-primary">View Sales Details</button>
    </form>
</div>