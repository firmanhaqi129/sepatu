<?php

$ar_menu['home'] = 'Home';
$ar_menu['products'] = 'Products';
$ar_menu['customers'] = 'Customers';
$ar_menu['sales'] = 'Sales';
$ar_menu['payments'] = 'Payments';
// $ar_menu['about'] = 'About';
// $ar_menu['checkout'] = 'Checkout';
// $ar_menu['contact'] = 'Contact';


//masukan hyperlink
$link['newproduct'] = 'newproduct.php';
$link['home'] = 'home.php';
$link['products'] = 'products.php';
$link['customers'] = 'customers.php';
$link['sales'] = 'sales.php';
$link['payments'] = 'payments.php';
// $link['about'] = 'about.php';
// $link['checkout'] = 'checkout.php';
// $link['contact'] = 'contact.php';
?>
