    <div id="templatemo_footer">
    	<p><?php
            foreach ($ar_menu as $k => $v) {
            echo '| <a href="index.php?hal='.$k.'">'.$v.'</a> | ';
            }?>
	</p>

    	Copyright © 2024 <a href="#">Shoe Shop Record System</a></div> <!-- END of templatemo_footer -->
    
</div> <!-- END of templatemo_wrapper -->
</div> <!-- END of templatemo_body_wrapper -->

</body>
</html>
