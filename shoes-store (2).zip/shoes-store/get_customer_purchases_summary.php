<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customer Purchase Summary</title>
</head>
<body>
    <h1>Customer Purchase Summary</h1>
    <?php
        $customer_id = 1; // Contoh ID pelanggan, bisa disesuaikan
        $mysqli = new mysqli("localhost", "root", "", "sepatu");

        // Check koneksi
        if($mysqli === false){
            die("ERROR: Could not connect. " . $mysqli->connect_error);
        }

        // Panggil stored procedure
        $sql = "CALL GetCustomerPurchaseSummary($customer_id)";
        if($result = $mysqli->query($sql)){
            if($result->num_rows > 0){
                echo "<ul>";
                while($row = $result->fetch_array()){
                    echo "<li>" . $row['sale_date'] . " - " . $row['total_amount'] . "</li>";
                }
                echo "</ul>";
                $result->free();
            } else{
                echo "No purchases found for this customer.";
            }
        } else{
            echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
        }

        // Tutup koneksi
        $mysqli->close();
    ?>
</body>
</html>
