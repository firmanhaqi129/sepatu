<?php

error_reporting(0);
session_start();

include_once 'dbconection.php';
//sertakan atau panggil potongan potongan layout web
include_once 'ar_menu.php';
include_once 'header.php';
include_once 'menu.php';
include_once 'sidebar.php';
include_once 'main.php';
include_once 'footer.php';

?>
 