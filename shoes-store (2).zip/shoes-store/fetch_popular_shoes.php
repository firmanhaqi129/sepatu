<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sepatu";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Call stored procedure
$sql = "CALL GetPopularShoes()";
$result = $conn->query($sql);

$shoes = [];
if ($result && $result->num_rows > 0) {
    // Fetch data from query result
    while($row = $result->fetch_assoc()) {
        $shoes[] = $row;
    }
}

// Close connection
$conn->close();

// Return result as JSON
echo json_encode($shoes);
?>
