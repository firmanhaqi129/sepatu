<?php
include_once 'dbconection.php';

try {
    // Capture request data
    $name = $_POST['name'];
    $categories = $_POST['categories'];
    $price = $_POST['price'];
    $picture = $_POST['picture'];
    $size = $_POST['size'];
    $stock = $_POST['stock'];
    $comment = $_POST['comment'];

    // Prepare data array
    $data = [$name, $categories, $price, $picture, $size, $stock, $comment];

    // Determine action
    $tombol = $_POST['proses'];
    if ($tombol == 'Save') {
        $sql = "INSERT INTO shoes (name, categories_id, price, picture, size, stock, comment) VALUES (?, ?, ?, ?, ?, ?, ?)";
    } elseif ($tombol == 'Edit') {
        $data[] = $_POST['idx']; // ID for update
        $sql = "UPDATE shoes SET name=?, categories_id=?, price=?, picture=?, size=?, stock=?, comment=? WHERE id=?";
    } elseif ($tombol == 'Remove') {
        unset($data); // Clear data array
        $data[] = $_POST['idx']; // ID for delete
        $sql = "DELETE FROM shoes WHERE id=?";
    } else {
        header('Location: index.php?hal=home');
        exit();
    }

    // Prepare and execute query
    $ps = $dbh->prepare($sql);
    $ps->execute($data);

    // Redirect to products page
    header('Location: index.php?hal=products');
} catch (PDOException $e) {
    // Handle and log error
    $errorMessage = $e->getMessage();
    echo "<script>alert('Error: $errorMessage'); window.history.back();</script>";
    error_log($e->getMessage());
}
?>
