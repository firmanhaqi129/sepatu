<style>
    /* Aturan CSS untuk menyesuaikan tampilan */
    .container {
        margin-top: 50px;
        width: 80%;
        margin: 0 auto;
    }
    .table {
        font-size: 16px;
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    .table th,
    .table td {
        color: #000; /* Warna font hitam */
        border: 1px solid #ddd; /* Garis tepi */
        padding: 8px;
        text-align: left;
    }
    .table th {
        background-color: #f2f2f2; /* Warna latar belakang header */
    }
    .table-striped tbody tr:nth-child(odd) {
        background-color: #f9f9f9; /* Warna latar belakang setiap baris ganjil */
    }
    .table-striped tbody tr:nth-child(even) {
        background-color: #fff; /* Warna latar belakang setiap baris genap */
    }
</style>

<?php
// Sertakan file koneksi ke database
include_once 'dbconection.php';

// Ambil data kategori sepatu
$sql_categories = "SELECT * FROM categories";
$stmt_categories = $dbh->query($sql_categories);

// Tampilkan form untuk memilih kategori
echo '<div class="container">';
echo '<h1>Total Sales by Category</h1>';
echo '<form action="" method="get">';
echo '<label for="category">Select Category:</label>';
echo '<select name="category" id="category">';
echo '<option value="">Select Category</option>';
while ($row_category = $stmt_categories->fetch(PDO::FETCH_ASSOC)) {
    echo '<option value="' . $row_category['id'] . '">' . $row_category['name'] . '</option>';
}
echo '</select>';
echo '<button type="submit" class="btn btn-primary">Show Sales</button>';
echo '</form>';

// Proses ketika form dikirimkan
if ($_SERVER['REQUEST_METHOD'] == 'GET' && isset($_GET['category'])) {
    $category_id = $_GET['category'];

    // Panggil stored procedure untuk mendapatkan total penjualan
    $stmt = $dbh->prepare("CALL GetTotalSalesByCategory(:category_id)");
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->execute();

    // Tampilkan hasil query
    echo '<div class="result">';
    echo '<h2>Sales Summary for Category:</h2>';
    echo '<table class="table table-striped">';
    echo '<thead>';
    echo '<tr>';
    echo '<th>Category Name</th>';
    echo '<th>Total Sales</th>';
    echo '<th>Total Revenue</th>';
    echo '</tr>';
    echo '</thead>';
    echo '<tbody>';
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo '<tr>';
        echo '<td>' . $row['category_name'] . '</td>';
        echo '<td>' . $row['total_sales'] . '</td>';
        echo '<td>' . $row['total_revenue'] . '</td>';
        echo '</tr>';
    }
    echo '</tbody>';
    echo '</table>';
    echo '</div>';
}
echo '</div>';
?>
