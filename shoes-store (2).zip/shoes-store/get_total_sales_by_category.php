<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Total Sales by Category</title>
</head>
<body>
    <h1>Total Sales by Category</h1>
    <?php
        $category_id = 1; // Contoh kategori ID, bisa diubah sesuai kebutuhan
        $mysqli = new mysqli("localhost", "root", "", "sepatu");

        // Check koneksi
        if($mysqli === false){
            die("ERROR: Could not connect. " . $mysqli->connect_error);
        }

        // Panggil stored procedure
        $sql = "CALL GetTotalSalesByCategory($category_id)";
        if($result = $mysqli->query($sql)){
            if($result->num_rows > 0){
                while($row = $result->fetch_array()){
                    echo "Total sales for category " . $category_id . ": " . $row['total_sales'];
                }
                $result->free();
            } else{
                echo "No sales found for this category.";
            }
        } else{
            echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
        }

        // Tutup koneksi
        $mysqli->close();
    ?>
</body>
</html>
