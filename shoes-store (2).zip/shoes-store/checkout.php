<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
        }
        .content_half {
            width: 48%;
            display: inline-block;
            vertical-align: top;
        }
        .float_l {
            float: left;
        }
        .float_r {
            float: right;
        }
        .cleaner {
            clear: both;
        }
        .checkout {
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table td {
            border: 1px solid #CCCCCC;
            padding: 10px;
        }
        .more {
            text-decoration: none;
            color: blue;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <h1>Checkout</h1>
    <h5><strong>BILLING INFORMATION</strong></h5>
    <div class="content_half float_l checkout">
        Full Name (must be same as on your credit card):  
        <input type="text" id="fullName" style="width:300px;" />
        <br /><br />
        Address:
        <input type="text" id="address" style="width:300px;" />
        <br /><br />
        City:
        <input type="text" id="city" style="width:300px;" />
        <br /><br />
        Country:
        <input type="text" id="country" style="width:300px;" />
    </div>

    <div class="content_half float_r checkout">
        E-MAIL
        <input type="text" id="email" style="width:300px;" />
        <br /><br />
        PHONE<br />
        <span style="font-size:10px">Please, specify your reachable phone number. YOU MAY BE GIVEN A CALL TO VERIFY AND COMPLETE THE ORDER.</span>
        <input type="text" id="phone" style="width:300px;" />
    </div>

    <div class="cleaner h50"></div>
    <h3>SHOPPING CART</h3>
    <h4>TOTAL AMOUNT: <strong>$240</strong></h4>
    <p><input type="checkbox" id="termsCheckbox" /> I accept the <a href="#">terms of use</a> of this website.</p>
    <table>
        <tr>
            <td height="80px"><img src="images/paypal.gif" alt="paypal" /></td>
            <td width="400px;" style="padding: 0px 20px;">Recommended if you have a PayPal account. Fastest delivery time.</td>
            <td><a href="#" class="more" id="paypalLink">PAYPAL</a></td>
        </tr>
        <tr>
            <td height="80px"><img src="images/2co.gif" alt="paypal" /></td>
            <td width="400px;" style="padding: 0px 20px;">2Checkout.com, Inc. is an authorized retailer of goods and services. 2CheckOut accepts customer orders via online checks, Visa, MasterCard, Discover, American Express, Diners, JCB and debit cards with the Visa, Mastercard logo. Validate <a href="http://validator.w3.org/check?uri=referer" rel="nofollow">XHTML</a> &amp; <a href="http://jigsaw.w3.org/css-validator/check/referer" rel="nofollow">CSS</a>.</td>
            <td><a href="#" class="more" id="2checkoutLink">2CHECKOUT</a></td>
        </tr>
    </table>

    <script>
        function validateForm() {
            var fullName = document.getElementById('fullName').value;
            var address = document.getElementById('address').value;
            var city = document.getElementById('city').value;
            var country = document.getElementById('country').value;
            var email = document.getElementById('email').value;
            var phone = document.getElementById('phone').value;
            var termsCheckbox = document.getElementById('termsCheckbox').checked;

            if (fullName === "" || address === "" || city === "" || country === "" || email === "" || phone === "" || !termsCheckbox) {
                alert("Periksa Kembali Data");
                return false;
            } else {
                alert("Pembelian Berhasil Dilakukan");
                return true;
            }
        }

        document.getElementById('paypalLink').addEventListener('click', function(event) {
            event.preventDefault();
            validateForm();
        });

        document.getElementById('2checkoutLink').addEventListener('click', function(event) {
            event.preventDefault();
            validateForm();
        });
    </script>

</body>
</html>
