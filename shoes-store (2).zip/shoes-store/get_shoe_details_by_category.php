<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shoe Details by Category</title>
</head>
<body>
    <h1>Shoe Details by Category</h1>
    <?php
        $category_id = 1; // Contoh kategori ID, bisa diubah sesuai kebutuhan
        $mysqli = new mysqli("localhost", "username", "password", "shoes-store");
        
        // Check koneksi
        if($mysqli === false){
            die("ERROR: Could not connect. " . $mysqli->connect_error);
        }

        // Panggil stored procedure
        $sql = "CALL GetShoeDetailsByCategory($category_id)";
        if($result = $mysqli->query($sql)){
            if($result->num_rows > 0){
                echo "<ul>";
                while($row = $result->fetch_array()){
                    echo "<li>" . $row['name'] . " - " . $row['price'] . "</li>";
                }
                echo "</ul>";
                $result->free();
            } else{
                echo "No shoes found in this category.";
            }
        } else{
            echo "ERROR: Could not able to execute $sql. " . $mysqli->error;
        }

        // Tutup koneksi
        $mysqli->close();
    ?>
</body>
</html>