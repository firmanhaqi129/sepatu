<?php
// Sertakan file koneksi ke database
include_once 'dbconection.php';

if (isset($_GET['category_id'])) {
    $category_id = $_GET['category_id'];

    // Prepare statement to call the stored procedure
    $stmt = $dbh->prepare("CALL GetCustomerEmailsByCategory(:category_id)");
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->execute();

    // Fetch the results
    $emails = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // CSS Style untuk tabel
    echo '<style>
            .container {
                margin-top: 50px;
                width: 80%;
                margin: 0 auto;
            }
            .table {
                font-size: 16px;
                width: 100%;
                border-collapse: collapse;
            }
            .table th,
            .table td {
                color: #000;
                border: 1px solid #ddd;
                padding: 8px;
                text-align: left;
            }
            .table th {
                background-color: #f2f2f2;
            }
        </style>';

    ?>
    <div class="container">
        <h1>Customer Emails for Category ID <?php echo $category_id; ?></h1>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if (!empty($emails)) {
                        foreach ($emails as $email) {
                            ?>
                            <tr>
                                <td><?php echo $email['email']; ?></td>
                            </tr>
                            <?php
                        }
                    } else {
                        ?>
                        <tr>
                            <td>No emails found for this category.</td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
} else {
    echo "<div class='container'><p>No category ID provided.</p></div>";
}
?>
